#ifndef BACKDROP_H
#define BACKDROP_H
#include "types.h"

#define BACK_GND_SIZE 0x7CFA

extern const UINT8 backdrop[];

#endif /*BACKDROP_H*/