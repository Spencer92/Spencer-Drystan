#ifndef GRASS_H
#define GRASS_H
#include "types.h"

#define GRASS_SIZE 0x7CD00

extern const UINT8 grass[GRASS_SIZE];


#endif