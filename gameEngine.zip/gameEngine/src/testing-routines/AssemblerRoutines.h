#ifndef ASSEMBLER_ROUTINES_H
#define ASSEMBLER_ROUTINES_H

void clear(char* screen);

#endif
