/* Character bitmaps  */
#ifndef FONTS_H
#define FONTS_H
#include "types.h"

extern const UINT8  GameFontBitmaps[];
extern const UINT16 GameFontDescriptors[];

#endif /*FONTS_H*/
