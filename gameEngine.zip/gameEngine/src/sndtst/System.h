#ifndef SYSTEM_H
#define SYSTEM_H


long getTime();

#endif