#ifndef TYPES_H
#define TYPES_H
#define BOOL UINT8
#define TRUE  1
#define FALSE 0

typedef char* String;

typedef unsigned char UINT8;
typedef unsigned int  UINT16;
typedef unsigned long UINT32;


#endif
