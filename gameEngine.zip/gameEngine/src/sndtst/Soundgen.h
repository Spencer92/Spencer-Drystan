/*

Routines to generate sound 








*/
#ifndef SOUNDGEN_H
#define SOUNDGEN_H


#define A 0
#define B 1
#define C 2










#endif SOUNDGEN_H