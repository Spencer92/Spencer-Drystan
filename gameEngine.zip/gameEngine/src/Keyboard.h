#ifndef KEYBOARD_H
#define KEYBOARD_H

#include "types.h"

BOOL DSconis();
char DSnecin();
void DSconws(String output);
void DSconout(char output);


#endif 