#ifndef ASSESS_H
#define	ASSESS_H
extern void tankBehav(Tank* enemy, Tank* player, Missile* missile, int num_missiles);

#endif